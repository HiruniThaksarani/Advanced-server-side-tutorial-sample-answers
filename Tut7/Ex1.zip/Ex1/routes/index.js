 'use strict';

 const express = require('express');
 const mainController = require('../controllers/main');
 const userController = require('../controllers/user');
 const petController = require('../controllers/pet');
 const userPetController = require('../controllers/user-pet');
 const studentController = require('../controllers/student');


 const router = express.Router();

 // main
 router.get('/', mainController.index);

 // users
 router.get('/users', userController.list);
 router.get('/user/:user_id', userController.before, userController.show);
 router.get('/user/:user_id/edit', userController.before, userController.edit);
 router.put('/user/:user_id', userController.before, userController.update);

 // pets
 router.get('/pets', petController.list);
 router.get('/pet/:pet_id', petController.before, petController.show);
 router.get('/pet/:pet_id/edit', petController.before, petController.edit);
 router.put('/pet/:pet_id', petController.before, petController.update);

 // user-pet
 router.post('/user/:user_id/pet', userPetController.create);
// students
router.get('/students', studentController.list);
router.get('/student/:student_id', studentController.before, studentController.show);
router.get('/student/:student_id/edit', studentController.before, studentController.edit);

router.post('/student', studentController.create);

router.put('/student/:student_id', studentController.before, studentController.update);
router.patch('/student/:student_id', studentController.before, studentController.patch);

router.delete('/student/:student_id', studentController.before, studentController.delete);

module.exports = router;

